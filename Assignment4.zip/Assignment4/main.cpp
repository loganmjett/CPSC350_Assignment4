#include <iostream>
#include <string>
#include "Simulation.h"
using namespace std;

int main(int argc, char** argv)
{
    Simulation officeSim; //this simulation

    if (argc < 2) //checks to see if a file is given to simulate, if not then it denies the start of the simulation
    {
        cout << "**No file detected, please try again!**" << endl;
    }
    else if (argc >= 2) //if file is given
    {
        bool simming = true;
        string fileToSim = argv[1];
        int currTick = 0;
        int openWindows = 0;

        if (officeSim.isCorrectFile(fileToSim)) //one last check to see if the file is valid, if it is then sim starts
        {
            while(simming) //simulation takes place in this loop
            {
                if (officeSim.lineOfStudents.isEmpty())
                {
                    int fill = 0;

                    for (int i = 0; i < officeSim.totalWindows; ++i)
                    {
                        if ((officeSim.regWindows[i]->timeAtWindow) < 1)
                        {
                            fill++;
                        }
                    }
                    if (fill == officeSim.totalWindows)
                    {
                        simming = false;
                    }
                }
                for (int i = 0; i < officeSim.totalWindows; ++i)
                {
                    if (officeSim.regWindows[i]->timeAtWindow < 1)
                    {
                        if (!officeSim.lineOfStudents.isEmpty())
                        {
                            Students* student = officeSim.lineOfStudents.getFront();

                            if (student->timeAtArrival <= currTick)
                            {
                                if (officeSim.regWindows[i]->timeSpentIdle > 0)
                                {
                                    officeSim.registrarStats.enqueue(officeSim.regWindows[i]->timeSpentIdle);
                                }
                                officeSim.regWindows[i] = officeSim.lineOfStudents.dequeue();
                                officeSim.studentStats.enqueue(officeSim.regWindows[i]->timeInQueue);
                            }
                        }
                    }
                }
                currTick++; //ticks increase
                officeSim.ticksCounter(currTick);
            }
            for (int i = 0; i < officeSim.totalWindows; ++i)
            {
                if (officeSim.regWindows[i]->timeSpentIdle > 0)
                {
                    officeSim.registrarStats.enqueue(officeSim.regWindows[i]->timeSpentIdle);
                }
            }

            //standard output of findings
            cout << "1. Mean Student Wait was: " << officeSim.studentMean() << " minutes." << endl;
            cout << "2. Median Student Wait was: " << officeSim.studentMedian() << " minutes." << endl;
            cout << "3. Longest Student Wait was: " << officeSim.studentLongestWaitTime() << " minutes." << endl;
            cout << "4. Number of Students Who Waited Over Ten Minutes was: " << officeSim.studentsWaitingOverTen() << endl;
            cout << "5. Mean Window Idle was: " << officeSim.registrarMean() << " minutes." << endl;
            cout << "6. Longest Window Idle was: " << officeSim.registrarLongest() << " minutes." << endl;
            cout << "7. Number of Windows Idle Over Five Minutes was: " << officeSim.registrarOverFive() << endl;
        }
    }
    return 0;
}
