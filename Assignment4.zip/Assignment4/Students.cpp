#include <iostream>
#include "Students.h"

using namespace std;

Students::Students()
{
    timeAtWindow = 0;
    timeAtArrival = 0;
    timeInQueue = 0;
    timeSpentIdle = 0;
}

Students::Students(int time, int entry)
{
    timeAtWindow = time;
    timeAtArrival = entry;
    timeInQueue = 0;
    timeSpentIdle = 0;
}

Students::~Students()
{
  //nothing needed here
}
