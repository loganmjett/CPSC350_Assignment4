#include <iostream>
#include <string>
#include "Students.h"
#include "GenQueue.h"
using namespace std;

class Simulation
{
    public:
        Simulation(); //Constructor
        ~Simulation(); //Destructor

        bool isCorrectFile(string file); //Determines if the file given is valid and reads it in
        bool ticksCounter(int t); //counts the ticks (time)
        double studentMean(); //finds mean wait time
        double studentMedian(); //finds median wait time
        int studentLongestWaitTime(); //finds longest wait time
        int studentsWaitingOverTen(); //finds number of times a student waited longer than ten minutes
        double registrarMean(); //finds mean time to service a student
        int registrarLongest(); //finds longest time to service a student
        int registrarOverFive(); //finds number of times a servicing took over five minutes

        Students* *regWindows; //occupied windows
        GenQueue<Students*> lineOfStudents; //line of students waiting to be served
        GenQueue<int> studentStats; //keeps track of times from a student's perspective
        GenQueue<int> registrarStats; //keeps track of times from the registrar office perspective
        int *medianArrary; //finds median time of student waiting
        int *idleArray; //finds time windows spent idle
        int totalWindows;
        int totalStudents;

      private:
          int type; //type of data to be recorded
          int timeAtArrival; //tick at time student gets to window
          int timeAtWindow; //time spent at window
          int studentsPerTick; //number of students waiting at each tick
          int medianElement;
          int idleElement;
};
