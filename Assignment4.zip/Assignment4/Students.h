#include <iostream>
using namespace std;

class Students
{
    public:
        Students(); //Constructor
        Students(int time, int entry); //Overloaded Constructor
        ~Students(); //Destructor

        int timeAtWindow; //this student's time spent at window
        int timeAtArrival; //this student's arrival time
        int timeInQueue; //this student's time spent in line
        int timeSpentIdle; //idle time of registrar in relation to the student
};
