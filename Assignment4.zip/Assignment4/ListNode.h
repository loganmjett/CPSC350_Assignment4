#include <iostream>
using namespace std;

template <class T>
class ListNode
{
    private:

    public:

        ListNode(); //Constructor
        ListNode(T d); //Overloaded Constructor
        ~ListNode(); //Destructor

        T data; //data stored at node
        ListNode<T> *next; //previous node
        ListNode<T> *prev; //next node
};

template <class T>
ListNode<T>::ListNode()
{
  //nothing needed here
}

template <class T>
ListNode<T>::ListNode(T d)
{
    data = d;
    next = NULL;
    prev = NULL;
}

template <class T>
ListNode<T>::~ListNode()
{
    if (next != NULL)
    {
        next = NULL;
        prev = NULL;

        delete next;
        delete prev;
    }
}
