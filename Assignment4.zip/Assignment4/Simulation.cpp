#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <queue>
#include "Simulation.h"
using namespace std;

Simulation::Simulation()
{
    type = 1;
    timeAtArrival = 0;
    timeAtWindow = 0;
    studentsPerTick = 0;
    medianElement = 0;
    idleElement = 0;
    totalWindows = 0;
    totalStudents = 0;
}

Simulation::~Simulation()
{
    delete [] idleArray;
    delete [] medianArrary;
    delete [] regWindows;
}

bool Simulation::isCorrectFile(string file)
{
    string line;
    int lineNum = 1;

    ifstream inputStream;
    inputStream.open(file.c_str());

    try //gets each line in the file, or the number to be used as stats
    {
        getline(inputStream, line);
        totalWindows = atoi(line.c_str());

        regWindows = new Students*[totalWindows];

        for (int i = 0; i < totalWindows; ++i)
        {
            Students* student = new Students();
            regWindows[i] = student;
        }

        lineNum++;
    }
    catch (exception e) //will occur if something other than numbers is in the file to be simulated
    {
        cout << "This File Not Supported" << endl;
        return false;
    }

    while (getline(inputStream, line))
    {
        switch (type)
        {
            case (1):
            {
                try //gets each line in the file, or the number to be used as stats
                {
                    timeAtArrival = atoi(line.c_str());
                    type++;
                    lineNum++;
                }
                catch (exception e) //will occur if something other than numbers is in the file to be simulated
                {
                    cout << "This File Not Supported" << endl;
                    return false;
                }
                break;
            }
            case (2):
            {
                try //gets each line in the file, or the number to be used as stats
                {
                    if(line != "") //checks to see if line has a value, and simulation should continue
                    {
                        studentsPerTick = atoi(line.c_str());

                        for (int i = 0; i < studentsPerTick; ++i)
                        {
                            getline(inputStream, line);
                            lineNum++;

                            try //gets each line in the file, or the number to be used as stats
                            {
                                timeAtWindow = atoi(line.c_str());
                            }
                            catch (exception e) //will occur if something other than numbers is in the file to be simulated
                            {
                                cout << "This File Not Supported" << endl;
                                return false;
                            }

                            totalStudents++;

                            Students* student = new Students(timeAtWindow, timeAtArrival);

                            lineOfStudents.enqueue(student);
                        }
                        type--;
                    }
                }
                catch (exception e) //will occur if something other than numbers is in the file to be simulated
                {
                    cout << "This File Not Supported" << endl;
                    return false;
                }

                break;
            }
            default:
                break;
        }
    }
    return true;
}

bool Simulation::ticksCounter(int t)
{
    for (int i = 0; i < totalWindows; ++i)
    {
      //data for this tick
        if( regWindows[i]->timeAtWindow > 0)
        {
            regWindows[i]->timeAtWindow--;
        }
        else
        {
            regWindows[i]->timeSpentIdle++;
        }
    }

    if (!lineOfStudents.isEmpty())
    {
        ListNode<Students*> *curr = lineOfStudents.front;

        while (curr != NULL)
        {
            if (curr->data->timeAtArrival < t)
            {
                curr->data->timeInQueue += 1;
            }
            curr = curr->next;
        }
    }
    return true;
}

double Simulation::studentMean()
{
    ListNode<int> *curr = studentStats.front;

    double stuMean = 0;
    double sum = 0;
    double counter = 0;

    while (curr != NULL)
    {
        sum += curr->data;
        curr = curr->next;
        counter++;
    }
    if (counter == 0)
    {
        return 0;
    }
    stuMean = sum / counter;
    return stuMean;
}

double Simulation::studentMedian()
{
    ListNode<int> *curr = studentStats.front;

    double medWait = 0;
    medianElement = 0;

    while (curr != NULL)
    {
        curr = curr->next;
        medianElement++;
    }

    if (medianElement == 0)
    {
        return 0;
    }
    else
    {
        medianArrary = new int[medianElement];
        curr = studentStats.front;

        for (int i = 0; i < medianElement; ++i)
        {
            medianArrary[i] = curr->data;
            curr = curr->next;
        }
        sort(medianArrary, medianArrary + medianElement);
        if (medianElement % 2 == 1)
        {
            double d = 0;
            int r = 0;

            r = (medianElement/2) + 1;
            d = medianArrary[r];

            return d;
        }
        else
        {
            double d = 0;
            int f = 0;
            int b = 0;

            f = medianElement/2;
            b = (medianElement/2) + 1;

            if (medianArrary[b] == 0)
            {
                return 0;
            }

            d = double(medianArrary[f])/double(medianArrary[b]);

            return d;
        }
    }
}

int Simulation::studentLongestWaitTime()
{
    if (medianElement == 0)
    {
        return 0;
    }
    else
    {
        return medianArrary[medianElement - 1];
    }
}

int Simulation::studentsWaitingOverTen()
{
    if (medianElement == 0)
    {
        return 0;
    }
    else
    {
        int numOverTen = 0;

        for (int i = 0; i < medianElement; ++i)
        {
            if (medianArrary[i] > 10)
            {
                ++numOverTen;
            }
        }
        return numOverTen;
    }
}

double Simulation::registrarMean()
{
    ListNode<int> *curr = registrarStats.front;

    double regMean = 0;
    double sum = 0;
    double counter = 0;

    while (curr != NULL) {
        sum += curr->data;
        curr = curr->next;

        counter++;
    }

    if (counter == 0)
    {
        return 0;
    }

    regMean = sum / counter;
    return regMean;
}

int Simulation::registrarLongest()
{
    ListNode<int> *curr = registrarStats.front;

    idleElement = 0;

    while (curr != NULL)
    {
        curr = curr->next;
        idleElement++;
    }

    idleArray = new int[idleElement];

    curr = registrarStats.front;

    for (int i = 0; i < idleElement; ++i)
    {
        idleArray[i] = curr->data;
        curr = curr->next;
    }

    sort(idleArray, idleArray + idleElement);

    return (idleArray[idleElement - 1]);
}

int Simulation::registrarOverFive()
{
    int numOverFive = 0;

    for (int i = 0; i < idleElement; ++i)
    {
        if (idleArray[i] > 5)
        {
            ++numOverFive;
        }
    }

    return numOverFive;
}
