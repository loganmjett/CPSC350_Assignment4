#include <iostream>
#include "ListNode.h"
using namespace std;

template <class T>
class GenQueue
{
    public:

        GenQueue(); //Constructor
        ~GenQueue(); //Destructor

        void enqueue(T data);
        T dequeue();
        T getFront();
        T getBack();
        void print(); //iterates and prints through list
        bool isEmpty();
        int getSize();

        int numElements; //number of elements in the array
        ListNode<T> *front; //pointer to the front of the queue
        ListNode<T> *back; //pointer to the rear of the queu
};

template <class T>
GenQueue<T>::GenQueue()
{
    numElements = 0;
    front = NULL;
    back = NULL;
}

template <class T>
GenQueue<T>::~GenQueue()
{

}

template <class T>
void GenQueue<T>::enqueue(T data)
{
    ListNode<T> *node = new ListNode<T>(data);

    if (numElements == 0)
    {
        front = node;
    }
    else
    {
        back->next = node;
        node->prev = back;
    }

    back = node;
    ++numElements;
}

template <class T>
T GenQueue<T>::dequeue()
{
    if (!isEmpty())
    {
        ListNode<T> *node = front;

        T temp = node->data;

        if (front->next == NULL)
        {
            front = NULL;
            back = NULL;
        }
        else
        {
            front->next->prev = NULL;
            front = front->next;
        }

        delete node;
        --numElements;
        return temp;
    }
    else
    {
        return T();
    }
}

template <class T>
T GenQueue<T>::getFront()
{
    return front->data;
}

template <class T>
T GenQueue<T>::getBack()
{
    return back->data;
}

template <class T>
void GenQueue<T>::print()
{
    ListNode<T> *curr = front;

    while (true)
    {
        if (curr != NULL)
        {
            cout << curr->data << endl;
            curr = curr->next;
        }
        else
        {
            break;
        }
    }
}

template <class T>
bool GenQueue<T>::isEmpty()
{
    return (numElements == 0);
}

template <class T>
int GenQueue<T>::getSize()
{
    return numElements;
}
